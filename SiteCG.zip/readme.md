## Projeto - Site Clube dos Generais
#### Modernização do site do CG com visual LandPage
#### Framework Materialize e Laravel

Site temporário desenvolvido para mudança de hospedagem. 
Limitado a exibição dos PodCasts

##### Versão 5.1.x - LTS de: 09/07/2015 até: 09/07/2018
 

## Banco de Dados - Antigo
#### Recuperação de dados existentes

Estrutura do banco de Dados antigo determinada. Backup de Dados disponível
Informações na Pasta "BancoAntigo"
###### Nome do banco para efeito de desenvolvimento: cgantigo

## Banco de Dados - Novo (remodelado)
#### Inclusão de novas informações e relacionamentos

Em andamento

